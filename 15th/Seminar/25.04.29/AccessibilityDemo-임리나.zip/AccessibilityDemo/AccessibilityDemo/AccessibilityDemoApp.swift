//
//  AccessibilityDemoApp.swift
//  AccessibilityDemo
//
//  Created by LinaLim on 2025.04.08.
//

import SwiftUI

@main
struct AccessibilityDemoApp: App {
  var body: some Scene {
    WindowGroup {
      MainView()
    }
  }
}
