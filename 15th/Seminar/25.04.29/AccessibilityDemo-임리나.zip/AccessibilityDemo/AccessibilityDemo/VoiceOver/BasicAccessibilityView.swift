//
//  ContentView.swift
//  AccessibilityTest
//
//  Created by LinaLim on 2025.04.08.
//

import SwiftUI

struct BasicAccessibilityView: View {
  @State var isOn: Bool = true
  
  var body: some View {
    ScrollView {
      VStack(spacing: 40) {
        Group {
          // 기본 텍스트 접근성
          SectionTitle(title: "텍스트 접근성")
          
          // static label은 안에 텍스트만 읽음
          Text("Hello, world!")
          
          // 라벨을 지정하면, 적혀있는 텍스트는 보이지 않음
          Text("라벨 지정")
            .accessibilityLabel("안녕, 세계야!")
          
          // 라벨이 없으면 텍스트는 기본으로 읽음
          Text("밸류 지정")
            .accessibilityValue("지정한 밸류는 보이진 않고 들림")
          
          // 순서는 라벨 -> 벨류
          Text("라벨 + 벨류")
            .accessibilityLabel("안녕, 세계야!")
            .accessibilityValue("지정한 밸류는 보이진 않고 들림")
          
          // 벨류를 먼저 지정한다고 해서 먼저 말하지 않음, inspector 순서대로 진행
          Text("벨류 + 라벨")
            .accessibilityValue("지정한 밸류는 보이진 않고 들림")
            .accessibilityLabel("안녕, 세계야!")
          
          Divider()
        }
        
        Group {
          // 모양 접근성
          SectionTitle(title: "모양과 이미지 접근성")
          
          HStack(spacing: 20) {
            // 시각적인 요소들 중 기본 라벨(벨류)가 없는 경우에는 따로 지정해줘야함
            Circle()
              .fill(.red)
              .frame(width: 50, height: 50)
            
            Circle()
              .fill(.blue)
              .frame(width: 50, height: 50)
              .accessibilityLabel("파란 원")
            
            RoundedRectangle(cornerRadius: 8)
              .fill(.green)
              .frame(width: 50, height: 50)
              .accessibilityValue("초록 사각형")
          }
          .padding(.horizontal)
          
          HStack {
            // 이미지는 여기 적는거 그대로 읽어서 진짜 조심해야함;;
            Image("매숑ㅇ매숑매매맴숑용")
              .resizable()
              .frame(width: 50, height: 50)
            
            // 텍스트는 따로 설명하지 않지만, 이미지의 경우 "이미지"라고 끝에 말해줌
            Image("매숑ㅇ매숑매매맴숑용")
              .resizable()
              .frame(width: 50, height: 50)
              .accessibilityLabel("아자핑 이미지")
            
            // 텍스트랑 마찬가지로 라벨값을 지정해주지 않으면, 이미지 이름 그대로 읽음 주의
            Image("매숑ㅇ매숑매매맴숑용")
              .resizable()
              .frame(width: 50, height: 50)
              .accessibilityValue("아자핑 이미지를 매숑이처럼 노출")
          }
          
          // 시스템 이미지는, 시스템 이름과 다르게 따로 밸류가 되어있는 것으로 보임
          HStack(spacing: 30) {
            VStack {
              Image(systemName: "pencil")
                .imageScale(.large)
                .foregroundStyle(.tint)
              
              Text("수정")
                .font(.caption)
            }
            
            VStack {
              Image(systemName: "heart")
                .imageScale(.large)
                .foregroundStyle(.pink)
              
              Text("사랑")
                .font(.caption)
            }
            
            VStack {
              Image(systemName: "star")
                .imageScale(.large)
                .foregroundStyle(.yellow)
              
              Text("즐겨찾기")
                .font(.caption)
            }
          }
          .padding(.horizontal)
          
          // 디바이더 기본 라벨 없음
          Divider()
        }
        
        Group {
          // 버튼 접근성
          SectionTitle(title: "버튼 접근성")
          
          // 텍스트는 따로 설명하지 않지만, 버튼의 경우 "버튼"이라고 끝에 말해줌
          Button {
            // action
          } label: {
            Text("버튼 기본형")
          }
          
          // on/off
          Button {
            isOn.toggle()
          } label: {
            Image(systemName: isOn ? "accessibility" : "voiceover")
              .imageScale(.large)
          }
          
          // isEnabled으로 각 상태별로 지정
          Button {
            isOn.toggle()
          } label: {
            Image(systemName: isOn ? "accessibility" : "voiceover")
              .imageScale(.large)
          }
          .accessibilityLabel("on", isEnabled: isOn)
          .accessibilityLabel("off", isEnabled: !isOn)
          
          // 버튼 안에 텍스트에 아까와 같이 지정해도 잘 됨
          Button {
            // action
          } label: {
            Text("버튼 내부 내용 테스트")
              .accessibilityLabel("버튼 안에 텍스트 라벨")
              .accessibilityValue("벨류가 잘 될까?")
          }
          
          // 근데 외부도 됨
          Button {
            // action
          } label: {
            Text("버튼 내부 외부 테스트")
          }
          .accessibilityLabel("버튼 안에 텍스트 라벨인데 밖에 둠")
          .accessibilityValue("벨류도 잘 될까?")
          
          // 근데 내부 외부 다하면 외부만 됨!
          Button {
            // action
          } label: {
            Text("버튼 내부/외부 테스트")
              .accessibilityLabel("버튼 안에 텍스트 라벨")
              .accessibilityValue("안 벨류가 잘 될까?")
          }
          .accessibilityLabel("버튼 안에 텍스트 라벨인데 밖에 둠")
          .accessibilityValue("밖 벨류가 잘 될까?")
          
          // 자꾸 끝에 버튼버튼 거리는거 시끄럽다!
          Button {
            print("버튼버튼")
          } label: {
            Text("버튼인거 말안해도 될거같아")
          }
          .accessibilityRemoveTraits(.isButton)

          // 텍스트이지만 버튼인척 해보자
          Text("난 버튼인척 하고싶은데?")
            .accessibilityAddTraits(.isButton)
          
          // 텍스트이지만 버튼인척 해보자
          Text("난 버튼인척 하고싶고, 온탭 제스쳐도 있어")
            .onTapGesture {
              print("탭탭!")
            }
            .accessibilityAddTraits(.isButton)
          
          // 텍스트이지만 버튼인척 하려면 무조건 설정 필요함!
          Text("난 버튼인척 하고싶고, 온탭 제스쳐도 있는데..?")
            .onTapGesture {
              print("탭탭!!")
            }
          
          Divider()
        }
        
        Group {
          // 요소 결합
          SectionTitle(title: "요소 결합하기")
          
          // 기본 상태
          HStack(spacing: 15) {
            Circle()
              .fill(.blue)
              .frame(width: 15, height: 15)
            
            VStack(alignment: .leading) {
              Text("댓글 내용입니다")
              Text("작성자: 김정민")
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button { } label: {
              Image(systemName: "heart")
                .foregroundColor(.pink)
            }
            
            Button { } label: {
              Image(systemName: "bubble.right")
                .foregroundColor(.blue)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          
          Text("요소 결합 전")
            .font(.caption)
            .foregroundColor(.secondary)
          
          // 요소 결합 후
          HStack(spacing: 15) {
            Circle()
              .fill(.blue)
              .frame(width: 15, height: 15)
              .accessibilityLabel("읽지 않음")
            
            VStack(alignment: .leading) {
              Text("댓글 내용입니다")
              Text("작성자: 김정민")
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            Spacer()
            
            Button { } label: {
              Image(systemName: "heart")
                .foregroundColor(.pink)
            }
            
            Button { } label: {
              Image(systemName: "bubble.right")
                .foregroundColor(.blue)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .combine)
          
          Text("요소 결합 후")
            .font(.caption)
            .foregroundColor(.secondary)
          
          Divider()
        }
        
        Group {
          // 접근성 결합 방식
          SectionTitle(title: "요소 결합 방식")
          
          // combine 방식 1
          HStack {
            Image(systemName: "person.circle.fill")
              .resizable()
              .frame(width: 40, height: 40)
              .foregroundColor(.blue)
            
            Text("combine 방식")
              .font(.headline)
            
            Spacer()
            
            Button {
              // action
            } label: {
              Text("팔로우")
                .font(.subheadline)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                  RoundedRectangle(cornerRadius: 12)
                    .fill(Color.blue)
                )
                .foregroundColor(.white)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .combine)
          
          // contain 방식
          HStack {
            Image(systemName: "person.circle.fill")
              .resizable()
              .frame(width: 40, height: 40)
              .foregroundColor(.green)
            
            Text("contain 방식(라벨X)")
              .font(.headline)
            
            Spacer()
            
            Button {
              // action
            } label: {
              Text("팔로우")
                .font(.subheadline)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                  RoundedRectangle(cornerRadius: 12)
                    .fill(Color.green)
                )
                .foregroundColor(.white)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .contain)
          
          // contain 방식
          HStack {
            Image(systemName: "person.circle.fill")
              .resizable()
              .frame(width: 40, height: 40)
              .foregroundColor(.green)
            
            Text("contain 방식(라벨O)")
              .font(.headline)
            
            Spacer()
            
            Button {
              // action
            } label: {
              Text("팔로우")
                .font(.subheadline)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                  RoundedRectangle(cornerRadius: 12)
                    .fill(Color.green)
                )
                .foregroundColor(.white)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .contain)
          .accessibilityLabel("사용자 프로필")
          
          // ignore 방식
          HStack {
            Image(systemName: "person.circle.fill")
              .resizable()
              .frame(width: 40, height: 40)
              .foregroundColor(.red)
            
            Text("ignore 방식(라벨X)")
              .font(.headline)
            
            Spacer()
            
            Button {
              // action
            } label: {
              Text("팔로우")
                .font(.subheadline)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                  RoundedRectangle(cornerRadius: 12)
                    .fill(Color.red)
                )
                .foregroundColor(.white)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .ignore)
          
          // ignore 방식
          HStack {
            Image(systemName: "person.circle.fill")
              .resizable()
              .frame(width: 40, height: 40)
              .foregroundColor(.red)
            
            Text("ignore 방식(라벨O)")
              .font(.headline)
            
            Spacer()
            
            Button {
              // action
            } label: {
              Text("팔로우")
                .font(.subheadline)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                  RoundedRectangle(cornerRadius: 12)
                    .fill(Color.red)
                )
                .foregroundColor(.white)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .ignore)
          .accessibilityLabel("사용자 프로필 카드")
          
          // ignore 방식
          HStack {
            Image(systemName: "person.circle.fill")
              .resizable()
              .frame(width: 40, height: 40)
              .foregroundColor(.red)
            
            Text("Hidden")
              .font(.headline)
            
            Spacer()
            
            Button {
              // action
            } label: {
              Text("팔로우")
                .font(.subheadline)
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                  RoundedRectangle(cornerRadius: 12)
                    .fill(Color.red)
                )
                .foregroundColor(.white)
            }
          }
          .padding()
          .background(
            RoundedRectangle(cornerRadius: 12)
              .fill(Color(.systemGray6))
          )
          .padding(.horizontal)
          .accessibilityElement(children: .ignore)
          .accessibilityHidden(true)
        }
      }
      .padding()
    }
    .navigationTitle("기본 접근성 예시")
  }
}

struct SectionTitle: View {
  let title: String
  
  var body: some View {
    Text(title)
      .font(.system(size: 17, weight: .bold))
      .foregroundColor(.primary)
      .frame(maxWidth: .infinity, alignment: .leading)
      .padding(.horizontal)
      .padding(.top, 10)
      .accessibilityAddTraits(.isHeader)
  }
}
