//
//  DragDropAccessibilityView.swift
//  AccessibilityTest
//
//  Created by LinaLim on 2025.04.08.
//

import SwiftUI

struct DragDropAccessibilityView: View {
  @State private var draggingSoundIndex: Int? = nil
  @State private var soundDropped = [false, false, false]
  @State private var droppedSounds = ["", "", ""]
  
  let availableSounds = ["종소리", "바다 소리", "새소리", "빗소리"]
  
  var body: some View {
    VStack {
      Text("소리를 드래그하여 알림에 추가하세요")
        .font(.headline)
        .padding()
      
      HStack(spacing: 20) {
        ForEach(0..<availableSounds.count, id: \.self) { index in
          SoundItem(name: availableSounds[index], isDragging: draggingSoundIndex == index)
            .onDrag {
              self.draggingSoundIndex = index
              return NSItemProvider(object: availableSounds[index] as NSString)
            }
            .accessibilityDragPoint(.init(x: 20, y: 20), description: "드래그")
        }
      }
      .padding()
      
      Spacer()
        .frame(height: 60)
      
      Text("친구 댓글 알림 설정")
        .font(.headline)
        .padding()
      
      ContactAlertView(
        name: "김민수",
        sounds: droppedSounds,
        onDrop: { index, itemProvider in
          _ = itemProvider.loadObject(ofClass: NSString.self) { (sound, _) in
            if let sound = sound as? String {
              DispatchQueue.main.async {
                self.droppedSounds[index] = sound
                self.soundDropped[index] = true
              }
            }
          }
          return true
        }
      )
      
      Spacer()
    }
    .padding()
    .navigationTitle("드래그 앤 드롭 접근성")
  }
}

// 소리 아이템 뷰
struct SoundItem: View {
  let name: String
  let isDragging: Bool
  
  var body: some View {
    VStack {
      ZStack {
        Circle()
          .fill(Color.blue.opacity(0.2))
          .frame(width: 60, height: 60)
        
        Image(systemName: "speaker.wave.2.fill")
          .resizable()
          .scaledToFit()
          .frame(width: 30, height: 30)
          .foregroundColor(.blue)
      }
      .opacity(isDragging ? 0.5 : 1.0)
      
      Text(name)
        .font(.caption)
    }
    .padding(8)
    .background(
      RoundedRectangle(cornerRadius: 12)
        .stroke(Color.blue, lineWidth: isDragging ? 2 : 0)
    )
    .accessibilityLabel("\(name), 드래그 가능")
  }
}

// 연락처 알림 뷰
struct ContactAlertView: View {
  let name: String
  let sounds: [String]
  let onDrop: (Int, NSItemProvider) -> Bool
  
  var body: some View {
    VStack(alignment: .leading, spacing: 10) {
      HStack {
        Image(systemName: "person.circle.fill")
          .resizable()
          .frame(width: 40, height: 40)
          .foregroundColor(.blue)
        
        Text(name)
          .font(.headline)
        
        Spacer()
      }
      
      Text("알림 소리:")
        .font(.subheadline)
        .padding(.top, 5)
      
      HStack(spacing: 20) {
        ForEach(0..<3) { index in
          DropTargetView(
            label: "소리 \(index + 1)",
            content: sounds[index],
            index: index,
            onDrop: onDrop
          )
          .accessibilityDropPoint(.init(x: 20, y: 20), description: "소리 \(index + 1) 설정")
        }
      }
    }
    .padding()
    .background(
      RoundedRectangle(cornerRadius: 12)
        .fill(Color(.systemGray6))
    )
    .padding(.horizontal)
  }
}

// 드롭 대상 뷰
struct DropTargetView: View {
  let label: String
  let content: String
  let index: Int
  let onDrop: (Int, NSItemProvider) -> Bool
  
  var body: some View {
    VStack {
      ZStack {
        Circle()
          .fill(content.isEmpty ? Color.gray.opacity(0.2) : Color.green.opacity(0.2))
          .frame(width: 60, height: 60)
        
        if content.isEmpty {
          Image(systemName: "plus")
            .resizable()
            .scaledToFit()
            .frame(width: 20, height: 20)
            .foregroundColor(.gray)
        } else {
          Image(systemName: "music.note")
            .resizable()
            .scaledToFit()
            .frame(width: 25, height: 25)
            .foregroundColor(.green)
        }
      }
      
      Text(content.isEmpty ? label : content)
        .font(.caption)
        .foregroundColor(content.isEmpty ? .gray : .primary)
    }
    .padding(8)
    .background(
      RoundedRectangle(cornerRadius: 12)
        .stroke(content.isEmpty ? Color.gray : Color.green, lineWidth: 1)
    )
    .onDrop(of: [.text], isTargeted: nil) { providers in
      if let provider = providers.first {
        return onDrop(index, provider)
      }
      return false
    }
    .accessibilityLabel(content.isEmpty ? "\(label), 비어있음" : "\(label), \(content)")
  }
}
