//
//  VoiceOver.swift
//  AccessibilityTest
//
//  Created by LinaLim on 2025.04.23.
//

import SwiftUI

struct VoiceOver: View {
  var body: some View {
    NavigationView {
      VStack(spacing: 30) {
        Text("voiceOver 데모")
          .font(.largeTitle)
          .fontWeight(.bold)
          .padding()
          .accessibilityAddTraits(.isHeader)
        
        NavigationLink(destination: BasicAccessibilityView()) {
          DemoButton(title: "기본 접근성 예시", subtitle: "라벨, 값, 특성 등")
        }
        
        NavigationLink(destination: DragDropAccessibilityView()) {
          DemoButton(title: "드래그 앤 드롭 예시", subtitle: "접근성 드래그 포인트와 드롭 포인트")
        }
        
        Spacer()
        
        Text("iOS 접근성 발표 자료")
          .font(.caption)
          .foregroundColor(.secondary)
      }
      .padding()
      .navigationTitle("voiceOver 데모")
    }
  }
}
