//
//  MainView.swift
//  AccessibilityTest
//
//  Created by LinaLim on 2025.04.08.
//

import SwiftUI

struct MainView: View {
  var body: some View {
    NavigationView {
      VStack(spacing: 30) {
        NavigationLink(destination: VoiceOver()) {
          DemoButton(title: "voiceOver 데모", subtitle: "catch up accessibility on SwiftUI")
        }
        
        NavigationLink(destination: DynamicType()) {
          DemoButton(title: "dynamic type 데모", subtitle: "get started with dynamic type")
        }
        
        Spacer()
        
        Text("iOS 접근성 발표 자료")
          .font(.caption)
          .foregroundColor(.secondary)
      }
      .padding()
      .navigationTitle("접근성 데모")
    }
  }
}

struct DemoButton: View {
  let title: String
  let subtitle: String
  
  var body: some View {
    HStack {
      VStack(alignment: .leading, spacing: 4) {
        Text(title)
          .font(.headline)
        
        Text(subtitle)
          .font(.subheadline)
          .foregroundColor(.secondary)
      }
      
      Spacer()
      
      Image(systemName: "chevron.right")
        .foregroundColor(.blue)
    }
    .padding()
    .background(
      RoundedRectangle(cornerRadius: 12)
        .fill(Color(.systemBackground))
        .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
    )
    .accessibilityElement(children: .combine)
  }
}
