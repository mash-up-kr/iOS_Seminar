//
//  BasicOfDynamicType.swift
//  AccessibilityDemo
//
//  Created by LinaLim on 2025.04.23.
//

import SwiftUI

struct BasicOfDynamicType: View {
  var body: some View {
    ScrollView {
      VStack(alignment: .leading, spacing: 20) {
        
        SectionTitle(title: "기본 동작 확인하기")
        
        Text("설정 > 손쉬운 사용 > 디스플레이 및 텍스트 크기 > 더 큰 텍스트")
          .font(.body)
        Text("설정시 바로바로 적용됨")
          .font(.caption2)
        
        Divider()
        
        Text("headline")
          .font(.headline)
        Text("subheadline")
          .font(.subheadline)
        
        Divider()
        
        Text("largeTitle")
          .font(.largeTitle)
        Text("title")
          .font(.title)
        Text("title2")
          .font(.title2)
        Text("title3")
          .font(.title3)
        
        Divider()
        
        Text("body")
          .font(.body)
        Text("caption")
          .font(.caption)
        Text("caption2")
          .font(.caption2)
        Text("footnote")
          .font(.footnote)
        Text("callout")
          .font(.callout)
        
        Divider()
        
        Text("아무것도 설정하지 않았을 때, 기본 설정된 값은 무엇일까?")
        
        Divider()
        
        SectionTitle(title: "디버깅 방법")
        
        Text("1. preview Dynamic Type Variants")
          .font(.caption)
        Text("Accessibility Inspector")
          .font(.caption)
      }
    }
    .padding()
    .toolbar {
      ToolbarItem(placement: .status) {
        
        Button("시스템 설정 열기") {
          if let url = URL(string: UIApplication.openSettingsURLString) {
            UIApplication.shared.open(url)
          }
        }
        .font(.footnote)
        .foregroundColor(.blue)
      }
    }
  }
}

#Preview {
  BasicOfDynamicType()
}
