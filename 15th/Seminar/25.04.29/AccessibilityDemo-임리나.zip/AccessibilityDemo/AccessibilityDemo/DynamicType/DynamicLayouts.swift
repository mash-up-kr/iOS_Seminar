//
//  DynamicLayouts.swift
//  AccessibilityDemo
//
//  Created by LinaLim on 2025.04.23.
//

import SwiftUI

struct DynamicLayouts: View {
  @Environment(\.dynamicTypeSize) var dynamicTypeSize
  
  let figures = [
    Figure(name: "Camera", imageName: "camera"),
    Figure(name: "Photos", imageName: "photo.on.rectangle"),
    Figure(name: "Memoji", imageName: "face.smiling"),
    Figure(name: "Monogram", imageName: "textformat")
  ]
  
  var layout: AnyLayout {
    dynamicTypeSize >= .accessibility1 ?
    AnyLayout(VStackLayout(spacing: 16)) :
    AnyLayout(HStackLayout(spacing: 16))
  }
  
  var body: some View {
    ScrollView {
      VStack(spacing: 20) {
        
        Image(.fake)
          .resizable()
          .frame(width: 300, height: 600)
        
        layout {
          ForEach(figures) { figure in
            FigureDetailView(figure: figure)
          }
        }
      }
      .frame(maxWidth: .infinity)
      .padding(.bottom)
    }
  }
}

struct FigureDetailView: View {
  let figure: Figure
  @Environment(\.dynamicTypeSize) var dynamicTypeSize

  var layout: AnyLayout {
    dynamicTypeSize <= .accessibility3 ?
    AnyLayout(VStackLayout(spacing: 16)) :
    AnyLayout(HStackLayout(spacing: 16))
  }
  
  var body: some View {
    layout {
      Image(systemName: figure.imageName)
        .resizable()
        .scaledToFit()
        .frame(width: 50, height: 50)
        .foregroundColor(.blue)

      Text(figure.name)
        .font(.body)

      Spacer()
    }
    .padding()
  }
}

// 피규어 모델
struct Figure: Identifiable {
  let id = UUID()
  let name: String
  let imageName: String
}

#Preview {
  DynamicLayouts()
}
