//
//  ScaledMetricView.swift
//  AccessibilityDemo
//
//  Created by LinaLim on 2025.04.23.
//

import SwiftUI

struct ScaledMetricView: View {
  @ScaledMetric var imageSize: CGFloat = 100
  @ScaledMetric(relativeTo: .headline) var headline = 100
  @ScaledMetric(relativeTo: .largeTitle) var largeTitle = 100
  
  var body: some View {
    ScrollView {
      VStack(spacing: 10) {
        Image(.balloon)
          .resizable()
          .frame(width: imageSize, height: imageSize)
          .padding(.top, 200)
        
        Text("balloon")
          .font(.headline)
        
        Spacer()
          .frame(height: 600)
        
        
        Image(.balloon)
          .resizable()
          .frame(width: headline, height: headline)
        
        Text("balloon")
          .font(.headline)
        
        Image(.balloon)
          .resizable()
          .frame(width: largeTitle, height: largeTitle)
        
        Text("balloon")
          .font(.largeTitle)
      }
      .frame(maxWidth: .infinity)
    }
  }
}

#Preview {
  ScaledMetricView()
}
