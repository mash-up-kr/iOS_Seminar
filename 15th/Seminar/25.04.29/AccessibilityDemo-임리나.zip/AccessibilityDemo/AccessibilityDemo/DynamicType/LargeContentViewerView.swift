//
//  LargeContentViewerView.swift
//  AccessibilityDemo
//
//  Created by LinaLim on 2025.04.23.
//

import SwiftUI

struct LargeContentViewerView: View {
  var body: some View {
    ScrollView {
      VStack(spacing: 20) {
        Image(.alertEX)
          .resizable()
          .frame(width: 300, height: 600)
        
        LargeContentButton(systemImage: "heart.fill", label: "좋아요")
        LargeContentButton(systemImage: "paperplane.fill", label: "공유")
      }
    }
  }
}

struct LargeContentButton: View {
  var systemImage: String
  var label: String
  
  var body: some View {
    Button(action: {}) {
      Image(systemName: systemImage)
        .resizable()
        .frame(width: 44, height: 44)
        .padding()
        .background(Color(.systemGray5))
        .clipShape(Circle())
    }
    .accessibilityLabel(label)
    .accessibilityShowsLargeContentViewer {
      VStack {
        Image(systemName: systemImage)
        Text(label)
      }
    }
  }
}

#Preview {
  LargeContentViewerView()
}
