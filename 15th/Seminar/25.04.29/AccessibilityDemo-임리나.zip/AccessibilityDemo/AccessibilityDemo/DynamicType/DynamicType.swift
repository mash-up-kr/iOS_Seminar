//
//  DynamicType.swift
//  AccessibilityTest
//
//  Created by LinaLim on 2025.04.23.
//

import SwiftUI

struct DynamicType: View {
  var body: some View {
    ScrollView {
      VStack(spacing: 30) {
        NavigationLink(destination: BasicOfDynamicType()) {
          DemoButton(title: "기본 다이나믹 타입 예시", subtitle: "설정, 사이즈 비교, 디버깅")
        }
        
        NavigationLink(destination: DynamicLayouts()) {
          DemoButton(title: "DynamicLayouts", subtitle: "레이아웃 변화")
        }
        
        NavigationLink(destination: LargeContentViewerView()) {
          DemoButton(title: "LargeContentViewerView", subtitle: "확대보기")
        }
        
        NavigationLink(destination: ScaledMetricView()) {
          DemoButton(title: "ScaledMetricView", subtitle: "이미지 사이즈 조절")
        }
        
        Spacer()
        
        Text("iOS 접근성 발표 자료")
          .font(.caption)
          .foregroundColor(.secondary)
      }
      .padding()
    }
    .navigationTitle("다이나믹 데모")
  }
}

#Preview {
  DynamicType()
}
